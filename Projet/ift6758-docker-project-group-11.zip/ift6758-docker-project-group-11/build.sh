#!/bin/bash

docker build --tag app --file Dockerfile.serving .
