from setuptools import find_packages, setup

setup(
    name='ift6758',
    packages=find_packages(),
    version='0.1.0',
    description='Sample project repo for IFT6758-2021',
    author='[Nazim Mamache, Arthur Boschet, Clément Detry, Frédéric Gagné]',
    license='',
)
