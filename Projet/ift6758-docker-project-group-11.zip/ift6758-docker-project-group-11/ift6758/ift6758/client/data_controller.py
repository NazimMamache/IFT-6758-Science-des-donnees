import sys
import pandas as pd

from processing import  update_events,convert_to_inputs,get_gamelist,get_game_info,totimeremain
from serving_client import ServingClient


class DataController():
    def __init__(self):
        '''
        Initialize the data controller
        '''

        self.current_data = self.initiate_data()
        self.servingClient = ServingClient()
        # self.game_list = get_gamelist()
        # self.game_id = str(self.game_list[-1])
        self.game_id = '2022020001'
        self.initiate_game_info()
        self.period = 0
        self.goal_home,self.goal_away,self.pred_away,self.pred_home = 0,0,0,0
        self.periodTime = '20:00'
        self.tracker_idx = 0

    def initiate_game_info(self):
        gameInfo = get_game_info(self.game_id)
        self.team_away = gameInfo.team_away.item()
        self.team_home = gameInfo.team_home.item()
        self.arena = gameInfo.Arena.item()


    def initiate_data(self):
        columns = ["eventIdx", 'event', 'Shot Type', 'x', 'y', 'isGoal',
                    'description',
               'period', 'teamName', 'gameSeconds', 'netEmpty',
               'gameID', 'distance', 'angle', 'lastEvent', 'last_x',
               'last_y', 'last_eventDist', 'timeSinceLastEvent',
               'isRebound', 'speed', 'angle_change',
               'powerplay_timer', 'sameteam_players',
                   'opposingteam_players','Prediction']
        return pd.DataFrame(columns=columns)


    def ping(self):
        '''
        update data and event index tracker
        '''

        new_events,timeList = update_events(self.game_id,self.tracker_idx)
        self.period = timeList[0]
        self.periodTime = totimeremain(timeList[1])
        if new_events.shape[0] == 0: return


        input_event = convert_to_inputs(new_events)
        prediction = self.servingClient.predict(input_event)
        new_events.reset_index(inplace=True,drop=True)
        new_events['Prediction'] = prediction
        self.current_data = pd.concat([self.current_data ,new_events],axis=0)
        self.tracker_idx = self.current_data.eventIdx.iloc[-1] if self.current_data.shape[0] != 0 else 0
        self.update_prediction_goal()

    def update_prediction_goal(self,seuil=0.78):
        df = self.current_data[self.current_data.event.isin(['Goal','Shot'])]
        home = df[df.teamName == self.team_home]
        away = df[df.teamName == self.team_away]
        self.goal_home = home.isGoal.sum()
        self.pred_home = round(home[home.Prediction > seuil].Prediction.sum(),1)
        self.goal_away = away.isGoal.sum()
        self.pred_away = round(away[away.Prediction >seuil].Prediction.sum(),1)


    def switch_game(self,new_game_id:str):
        '''
        switch_game load data another game

        new_game_id (str) : string of the game id to load
        '''

        self.game_id = new_game_id
        self.current_data = self.initiate_data()
        self.initiate_game_info()
        self.period = 0
        self.periodTime = '20:00'
        self.goal_home, self.goal_away, self.pred_away, self.pred_home = 0, 0, 0, 0
        self.tracker_idx = 0
        self.ping()

# if __name__ == "__main__":
#     test = DataController()
#     test.ping()
#     print(test.game_id)
#     print('Les équipes : ' +test.team_home + ' vs ' +test.team_away )
#     print("Lieu de rencontre: " + test.arena)
#     print('Period: '+ str(test.period) +' Temps restant: ' + str(test.periodTime) )
#     print('Actual ' + str(test.goal_home) + ' : Pred ' + str(test.pred_home))
#     print('Actual ' + str(test.goal_away) + ' : Pred ' + str(test.pred_away))
#     test.switch_game('2022020482')
#     print('Les équipes : ' +test.team_home + ' vs ' +test.team_away )
#     print("Lieu de rencontre: " + test.arena)
#     print('Period: '+ str(test.period) +' Temps restant: ' + str(test.periodTime) )
#     print('Actual ' + str(test.goal_home) + ' : Pred ' + str(test.pred_home))
#     print('Actual ' + str(test.goal_away) + ' : Pred ' + str(test.pred_away))

