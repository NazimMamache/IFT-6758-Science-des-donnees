import sys
sys.path.insert(1, '../hockeyviz_app_group_11')
sys.path.insert(1, '../src')
sys.path.insert(1, '..')

#general
from tqdm import tqdm

#scientific computing and data processing
import numpy as np
import pandas as pd

#our own modules
from features_helper_func import *

def get_team_rink_side(event, df_games):
    '''
    Gets the rink side of the team involves in a perticular play by play event
    Arguments:
        event (pd.DataFrame): row of the play by play dataframe corresponding to a perticular play
        df_games (pd.DataFrame): dataframe containing the games information
    Returns:
        rinkside (str): rinkside of the team involves ('left' of 'right')
    '''

    game_id = event.gameID
    team = event.teamName
    period = event.period

    if team == df_games.loc[game_id, 'team_home']:
        team_status = 'home'
    else:
        team_status = 'away'
    
    return df_games.loc[game_id, team_status+f'_rink_side_period_{period}']
    
    
def create_angle_feature(event, df_games):
    '''
    Computes angle from the goal associated with each play.
    Arguments:
        event (pd.DataFrame): row of the play by play dataframe corresponding to a perticular play
        df_games (pd.DataFrame): dataframe containing the games information
    Returns:
        angle (float or np.nan): angle from the goal if the rink side is specified by the API otherwise return nan.
    '''
    left_goal_coordinates = (-89.0, 0.0)
    right_goal_coordinates = (89.0, 0.0)

    coordinates = event.eventCoordinates
    if coordinates == None: return None
    # if event is a shot of shootout
    if df_games['hasShootout'].item() and event['period'] == 5:
        rinkside = 'right' if event['eventCoordinates'][0]<0 else 'left'
    else:
        rinkside = get_team_rink_side(event, df_games)

    if rinkside== 'right':
        return compute_angle(left_goal_coordinates, coordinates)
    elif rinkside == 'left':
        return compute_angle(right_goal_coordinates, coordinates)
    else:
        return np.nan
    
def create_distance_feature(event, df_games):
    '''
    Computes distances from the goal associated with each play. 
    Arguments:
        event (pd.DataFrame): row of the play by play dataframe corresponding to a perticular play
        df_games (pd.DataFrame): dataframe containing the games information
    Returns:
        distance (float or np.nan): distance from the goal if the rink side is specified by the API otherwise return nan.
    '''
    left_goal_coordinates = (-89.0,0.0)
    right_goal_coordinates = (89.0,0.0)
    
    coordinates = event.eventCoordinates
    rinkside = get_team_rink_side(event, df_games)
    
    if rinkside == 'right':
        return compute_distance(left_goal_coordinates, coordinates)
    elif rinkside == 'left':
        return compute_distance(right_goal_coordinates, coordinates)
    else:
        return np.nan
    
def rotate_coordinates_offensive(event, df_games):
    '''
    Rotates the coordinates into a single set of coordinates suitable for the offensive shot maps. 
    Arguments:
        event (pd.DataFrame): row of the play by play dataframe corresponding to a perticular play
        df_games (pd.DataFrame): dataframe containing the games information
    Returns:
        coordinates (tuple or np.nan): tuple of size 2 containing the coordinates (float) if the rink side is specified by the API otherwise return nan.
    '''
    
    #get team rink side
    coordinates = event.eventCoordinates
    rinkside = get_team_rink_side(event, df_games)
    
    #flip y axis to match  hockeyvis
    coordinates = (coordinates[0], -coordinates[1])
    
    if rinkside == 'right':
        return (-coordinates[0], -coordinates[1])
    elif rinkside == 'left':
        return coordinates
    else:
        return np.nan
    
def get_probability_goal_df(df, increment=10):
    '''
    Process the play by play dataframe (after the distance feature has been added) to get the probability of a shot being a goal into distance bins
    Arguments:
        df (pd.DataFrame): play by play dataframe with an added "Distance (feet)" column
        increment (float): size of the interval used for binning of distances
    Returns:
        df_bins_distance_collapsed (pd.DataFrame): dataframe containing the probability of a shot being a goal per bin (plus relevent information like standard error and goal count)
    '''
    pairs = list(np.asarray(df.loc[:, ["Distance (feet)", "isGoal"]], dtype=float))
    pairs.sort(key=lambda v: v[0])
    num = increment
    bins = []
    for pair in pairs:
        if pair[0] > num:
            num+=increment
        bins.append(np.array([(num-increment, num),pair[1]], dtype=object))

    df_bins_distance = pd.DataFrame(np.vstack(bins), columns=['Bins', 'Goal?'])

    prob_goal = []
    stderr_prob_goal = []
    count_goal = []
    bins = list(set(df_bins_distance.Bins.values))
    bins.sort()
    for b in bins:
        # bins_exit.append(b)
        prob_goal.append(df_bins_distance[df_bins_distance.Bins == b]['Goal?'].mean())
        stderr_prob_goal.append(df_bins_distance[df_bins_distance.Bins == b]['Goal?'].sem())
        count_goal.append(df_bins_distance[df_bins_distance.Bins == b]['Goal?'].count())

    df_bins_distance_collapsed = pd.DataFrame()
    df_bins_distance_collapsed['Distance Range (ft)'] =  bins
    df_bins_distance_collapsed['Goal Probability'] = prob_goal
    df_bins_distance_collapsed['Goal Count'] = count_goal
    df_bins_distance_collapsed['Standard Error of the Goal Probability'] = stderr_prob_goal
    return df_bins_distance_collapsed

    
def compute_number_shots_total(df):
    '''
    compute number of shots / hour for each coordinate of the court given a play by play matrix
    Arguments:
        df (pd.DataFrame): play by play dataframe
    Returns:
        shots_total (nd.array): matrix with the number of shots at each coordinate
    '''
    shot_data = np.vstack(
        [
            np.array([x for (x,y) in df.eventCoordinates.values]), 
            np.array([y for (x,y) in df.eventCoordinates.values])
        ]
    ).T
    shots_total = np.zeros(
        (
            int(100), 
            int(85)
        )
    )
    for shot in shot_data:
        shots_total[int(shot[0]), 42+int(shot[1])] += 1
    return shots_total

def distance_matrix_compute(len_x, len_y):
    '''
    computes the pairwise distance matrix.
    Arguments:
        len_x (int): length of x-axis
        len_y (int): length of y-axis
    Returns:
        distance_matrix (nd.array): pairwise distance of each location
    '''
    x = np.arange(0, len_x)
    y = np.arange(0, len_y)
    xv, yv = np.meshgrid(x, y, indexing='ij')
    meshpoints = np.stack([xv, yv]).reshape(2, 8500).T
    distance_matrix = np.linalg.norm(meshpoints[:, np.newaxis, :] - meshpoints[np.newaxis, :, :], axis=-1)
    return distance_matrix

def kernel_weights(len_x, len_y, kernel=gaussian_kernel):
    '''
    computes the weights of each point depending on location for the weighted sum.
    Arguments:
        len_x (int): length of x-axis
        len_y (int): length of y-axis
        kernel (func nd.array -> nd.array)
    Returns:
        weights (nd.array): weights of each point depending on location
    '''
    distance_matrix = distance_matrix_compute(len_x, len_y)
    weights = kernel(distance_matrix)
    return weights

def filter_kernel(matrix, weights, kernel=gaussian_kernel):
    '''
    Each point becomes weighted sum of matrix and the weights correspondind to the point of interest
    Arguments:
        matrix (np.array): matrix to be filtered (n x m)
        weights (np.array): weighted matrix (each row corresponds to a point in matrix) ((n*m) x (n*m))
    Returns:
        filtered_matrix: each point becomes weighted sum of matrix and the appropriate weights
    '''

    len_x = matrix.shape[0]
    len_y = matrix.shape[1]
    return (matrix.reshape(1, len_x*len_y) @ weights).reshape(len_x, len_y)
    
    
    
def compute_team_shots_per_hour(team_shot_agg, df_games, weights, kernel=gaussian_kernel):
    '''
    Computes the excess shot/hour maps for each team
    Arguments:
        team_shot_agg (pd.DataFrame): team shots dataframe
        df_games (pd.DataFrame): game info dataframe
        weights (nd.array): weighted matrix (each row corresponds to a point in the court)
        kernel (func nd.array -> nd.array): transform array function
    Returns:
        diffs (list(nd.array)): list of all the excess shotmaps 
        teams (list(str)): list of corresponding teams
    '''
    teams = list(set(list(df_games.team_away.values) + list(df_games.team_home.values)))
    teams.sort()
    
    #compute the average number of shots per hour (assumption each game = 60 minutes)
    avg_shots_per_hour_league = compute_number_shots_total(team_shot_agg)/(2*len(df_games))
    
    diffs = []
    for team in tqdm(teams):
        #compute the average number of shots per hour (assumption each game = 60 minute)
        df_games_team = df_games[(df_games.team_away == team).values | (df_games.team_home == team).values]
        team_shot_agg_team = team_shot_agg[(team_shot_agg.teamName == team).values]
        
        avg_shots_per_hour_team = compute_number_shots_total(team_shot_agg_team)/len(df_games_team)
        diff_team = avg_shots_per_hour_team - avg_shots_per_hour_league
        diffs.append(filter_kernel(diff_team, weights,kernel=kernel))
    
    return diffs, teams



def get_penalty_schedule(df_penalty,isHome):
    '''
    Computes the excess shot/hour maps for each team
    Arguments:
        df_penalty (pd.DataFrame): dataframe with all penalty event informations
        isHome (booleans): do we want schedule for home team ?
    Returns:
        numpy matrix(int) : time schedule, first columns is the beginning of the
        event. second columns is the end of the event. Third, columns the number
        of player in penalty for this time range
    '''

    penalty_timeinfo = df_penalty[df_penalty['isTeamHome'] == isHome].loc[:, ['timeStart', 'timeEnd']].to_numpy()
    penalty_timeranges = penalty_timeinfo.copy()

    playerPena = np.array([[0, 0, 0]])

    # if there is no penalty
    if penalty_timeinfo.size == 0:
        return playerPena

    # While all time ranges are cover
    while playerPena[-1, 1] < penalty_timeinfo[-1, 1]:

        # we check last time range added in penalty count
        last_timerange = playerPena[-1, :-1]
        # and next time range to append
        next_timerange = penalty_timeranges[0, :]

        # if there is a gap between time ranges
        if last_timerange[1] < next_timerange[0]:
            # we fill the zonne with 0 player in penalty
            playerPena = np.vstack((playerPena, [last_timerange[1], next_timerange[0], 0]))

        # if there are successif
        elif last_timerange[1] == next_timerange[0]:
            # we happen with one player in penalty for next time range
            playerPena = np.vstack((playerPena, [last_timerange[1], next_timerange[1], 1]))
            penalty_timeranges = penalty_timeranges[1:, :] # pop time range

        else:  # if there are overlapping
            # we pop last time range
            current_num = playerPena[-1, -1]
            playerPena = playerPena[:-1, :]

            # do time ranges begin at the same time ?
            if last_timerange[0] == next_timerange[0]:

                # do they end at the same time?
                if last_timerange[1] == next_timerange[1]:
                    current_num = current_num + 1 if current_num < 2 else 2
                    playerPena = np.vstack((playerPena, [last_timerange[0], next_timerange[1], current_num]))
                    penalty_timeranges = penalty_timeranges[1:, :]
                # last one saved end before next to append?
                elif last_timerange[1] < next_timerange[1]:
                    current_num = current_num + 1 if current_num < 2 else 2
                    playerPena = np.vstack((playerPena, [last_timerange[0], last_timerange[1], current_num]))  # a-c
                    playerPena = np.vstack((playerPena, [last_timerange[1], next_timerange[1], current_num - 1]))  # c-d
                    penalty_timeranges = penalty_timeranges[1:, :]
                else: # if not
                    current_num = current_num + 1 if current_num < 2 else 2
                    playerPena = np.vstack((playerPena, [last_timerange[0], next_timerange[1], current_num]))  # a -d
                    playerPena = np.vstack((playerPena, [next_timerange[1], last_timerange[1], current_num - 1]))  # c -d
                    penalty_timeranges = penalty_timeranges[1:, :]

            # does last time range begin before the next to append ?
            elif last_timerange[0] < next_timerange[0]:

                playerPena = np.vstack((playerPena, [last_timerange[0], next_timerange[0], current_num]))

                # do they end at the same time?
                if last_timerange[1] == next_timerange[1]:
                    current_num = current_num + 1 if current_num < 2 else 2
                    playerPena = np.vstack((playerPena, [next_timerange[0], next_timerange[1], current_num]))
                    penalty_timeranges = penalty_timeranges[1:, :]

                # last one saved end before next to append ?
                elif last_timerange[1] < next_timerange[1]:
                    current_num = current_num + 1 if current_num < 2 else 2
                    playerPena = np.vstack((playerPena, [next_timerange[0], last_timerange[1], current_num]))
                    playerPena = np.vstack((playerPena, [last_timerange[1], next_timerange[1], current_num - 1]))
                    penalty_timeranges = penalty_timeranges[1:, :]
                else:  # if not
                    current_num = current_num + 1 if current_num < 2 else 2
                    playerPena = np.vstack((playerPena, [next_timerange[0], next_timerange[1], current_num]))
                    playerPena = np.vstack((playerPena, [next_timerange[1], last_timerange[1], current_num - 1]))
                    penalty_timeranges = penalty_timeranges[1:, :]

            else:  # if not
                # we need to pop the second to last item added to penalty list
                previous_lasttimeranges = playerPena[-1, :-1]
                prev_num = playerPena[-1, -1]
                playerPena = playerPena[:-1, :]

                # add time zone between second to last and next time range
                playerPena = np.vstack((playerPena, [previous_lasttimeranges[0], next_timerange[0], prev_num]))

                # if time range to append end before last added begin
                if next_timerange[1] <= last_timerange[0]:

                    if next_timerange[1] == last_timerange[0]:
                        prev_num = prev_num + 1 if prev_num < 2 else 2
                        playerPena = np.vstack((playerPena, [next_timerange[0], last_timerange[0], prev_num]))
                        playerPena = np.vstack((playerPena, [last_timerange[0], last_timerange[1], current_num]))
                        penalty_timeranges = penalty_timeranges[1:, :]
                    else:
                        prev_num = prev_num + 1 if prev_num < 2 else 2
                        playerPena = np.vstack((playerPena, [next_timerange[0], next_timerange[1], prev_num]))
                        playerPena = np.vstack((playerPena, [next_timerange[1], last_timerange[0], prev_num-1]))
                        playerPena = np.vstack((playerPena, [last_timerange[0], last_timerange[1], current_num]))
                        penalty_timeranges = penalty_timeranges[1:, :]

                # if next time range  ends before last added end

                elif next_timerange[1] <= last_timerange[1]:
                    prev_num = prev_num + 1 if prev_num < 2 else 2
                    current_num = current_num + 1 if current_num < 2 else 2
                    playerPena = np.vstack((playerPena, [next_timerange[0], last_timerange[0], prev_num]))
                    playerPena = np.vstack((playerPena, [last_timerange[0], next_timerange[1], current_num]))
                    if next_timerange[1] != last_timerange[1]:
                        playerPena = np.vstack((playerPena, [next_timerange[1], last_timerange[1], current_num-1]))
                    penalty_timeranges = penalty_timeranges[1:, :]
                else: # if not
                    prev_num = prev_num + 1 if prev_num < 2 else 2
                    current_num = current_num + 1 if current_num < 2 else 2
                    playerPena = np.vstack((playerPena, [next_timerange[0], last_timerange[0], prev_num]))
                    playerPena = np.vstack((playerPena, [last_timerange[0], last_timerange[1], current_num]))
                    playerPena = np.vstack((playerPena, [last_timerange[1], next_timerange[1], current_num - 1]))
                    penalty_timeranges = penalty_timeranges[1:, :]
    return playerPena[1:,:]

def num_player(penalty_sched,period_time):
    '''
    Function that takes a period of times (seconds) and a period schedule that
    contains a time range and the number of players in penalty for that time range

    penalty_sched : numpy matrix (int) - schedule of how many players are playing
                                        for one team. First columns, begining of
                                        time range. Second columns, end of time range.
                                        Third, is how many players are in penalty.
    period_time (int) - integer of the number of seconds for that event
    '''

    # for each time range
    for i in range(penalty_sched.shape[0]):
        # we check if event is occuring during
        if period_time >= penalty_sched[i,0] and period_time < penalty_sched[i,1]:
            # return the name of non-goal player remaining on ice
            return 5-penalty_sched[i,2]
    return 5 # over penalty schedule so no power play


def timer_powerplay(penalty_sched,period_time):
    '''
    Function that takes a period of times (seconds) and a period schedule that
    contains a time range and the number of players in penalty for that time range

    penalty_sched : numpy matrix (int) - schedule of how many players are playing
                                        for one team. First columns, begining of
                                        time range. Second columns, end of time range.
                                        Third, is how many players are in penalty.
    period_time (int) - integer of the number of seconds for that event
    '''

    # for each time range
    for i in range(penalty_sched.shape[0]):
        # we check if event is occuring during
        if period_time >= penalty_sched[i,0] and period_time < penalty_sched[i,1]:
            # return the name of non-goal player remaining on ice
            if penalty_sched[i,2] == 0 :
                return 0
            else:
                while penalty_sched[i,2] != 0 and i != 0:
                    i -= 1
                return penalty_sched[i,1] # return start of powerplay

    return 0 # over penalty schedule so no power play

def consolidation_timer_pp(gameSeconds,timerStartHome,timerStartAway,isHome,teamName):
    '''
        gameSeconds (float) : time of event in game (second)
        timerStartHome (float) : timer for home team (second)
        timerStartAway (float) : timer for away team (second)
        isHome (booleans) :  is the team playing at home ?
        teamName (str) : name of team

        Merge two powerplay count for both teams.
    '''

    return 0 if max(timerStartHome, timerStartAway) == 0 else gameSeconds - max(timerStartHome, timerStartAway)

    ''' 
    print(teamName)
    print(f"{gameSeconds}/{timerStartHome}/{timerStartAway}/{isHome}")
    if not teamName:
        print(0 if max(timerStartHome,timerStartAway) == 0 else gameSeconds - max(timerStartHome,timerStartAway))
        return 0 if max(timerStartHome,timerStartAway) == 0 else gameSeconds - max(timerStartHome,timerStartAway)
    elif isHome:
        print(0.0 if timerStartHome == 0.0 else gameSeconds - timerStartHome)
        return 0 if timerStartHome == 0 else gameSeconds - timerStartHome
    else:
        print(0 if timerStartAway == 0 else gameSeconds - timerStartAway)
        return 0 if timerStartAway == 0 else gameSeconds - timerStartAway
    '''

def numberplayers_dispatch(isHome,teamName,homePlayers,awayPlayers,isSameTeam):
    '''
    isHome (booleans) : is the team the home team or not?
    teamName (str) : what is the team name?
    homePlayers (int) : number of players for home team in event
    awayPlayers (int) : numbers of players for away team in event
    isSameTeam (booleans) : de we want result for players on concern team or
                            adverse team ?

    return number of player against or with team of event in relation with
    '''
    # if no team in event
    if not teamName:
        return 0
    elif isHome:
        return homePlayers if isSameTeam else awayPlayers
    else:
        return awayPlayers if isSameTeam else homePlayers

