#scientific computing and data processing
import numpy as np
import pandas as pd

def compute_distance(xy1, xy2):
    '''
    Computes distance between two points
    Arguments:
        xy1 (tuple): tuple of size 2 of the form (x, y) where x and y are floating point numbers
        xy2 (tuple): tuple of size 2 of the form (x, y) where x and y are floating point numbers
    Returns:
        distance (float): distance between two points

    '''
    if xy2 == None or xy1 == None:
        return np.nan
    xy1 = np.asarray(xy1)
    xy2 = np.asarray(xy2)
    return np.linalg.norm(xy1-xy2)


def compute_angle(goal_coordinates, coordinates):
    '''
    Computes angle between two vectors
    Arguments:
        goal_coordinates (tuple): tuple of size 2 of the form (x, y) where x and y are floating point numbers
        coordinates (tuple): tuple of size 2 of the form (x, y) where x and y are floating point numbers
    Returns:
        angle (float): angle between two vectors

    '''
    if goal_coordinates == None or coordinates == None:
        return None

    goal_coordinates = np.asarray(goal_coordinates)
    coordinates = np.asarray(coordinates)

    v1 = -goal_coordinates
    v2 = coordinates-goal_coordinates

    return np.rad2deg(np.arccos(np.dot(v1, v2)/(np.linalg.norm(v1) * np.linalg.norm(v2))))



def angle_change(isRebound: bool, angle: float, last_angle: float,x:float,last_x:float) -> float:
    '''
    Function that calculate angle variation for shot that are rebound.

    Arguments:
        isRebound (bool) : if shot is a rebound or not
        angle (float) : angle from current shot
        last_angle (float) : angle from previous shot
        x (float) : x coordinate for current shot
        last_x (float) : x coordinate from last shot
    Returns:
        float : angle variation if rebound
    '''

    if not isRebound: return 0

    if np.sign(x) == np.sign(last_x):
        return np.abs(last_angle-angle)
    else:
        return angle + last_angle

def speed_events(dist: float, time: float) -> float:
    '''
    Function that calculate 'speed' between events by
    dividing the distance by the times beetween current events
    and previous ones

    Arguments:
        dist (float) : distance between events
        time (float) : time between events
    Returns:
        float : speed between events
    '''

    if np.isnan(dist) or np.isnan(time) or time == 0:
        return None
    return dist/time

def rebound_identification(event:str,last_Event:str) -> bool:
    '''
    Function that returns True if current event is a shot/goal and
    False otherwise.

    Arguments:
        event (str) : current event
        last_Event (str) : previous event
    Returns:
        booleans : booleans that tells if current event is rebound or not
    '''

    type_of_shot = ['Missed Shot', 'Shot', 'Goal', 'Blocked Shot'] # À discuter *****
    return (event in type_of_shot) and (last_Event in type_of_shot)



###### kernels used by the advanced shot map visualization for smoothing

def gaussian_kernel(distance, area=100):
    '''
    gaussian kernel computed on distances (gives a weight to each point depending on the distance) assuming that the considered area must be equal to "area"
    Arguments:
        distance (nd.array): matrix with distances of interest corresponding to an array of points 
        area (float): area covered by the gaussian weights  (computed via the result that the integral of the gaussian integral in 2D)
    Returns:
        gaussian_weights (nd.array): matrix with the same size as the distance matrix with corresponding gaussian weights for each underlying point.
    '''
    sigma=np.sqrt(area/(2*np.pi))
    return np.exp(-distance**2/(2*sigma**2))
    

def circle_kernel(distance, area=100):
    '''
    returns 1 for each point within the area of circle with area equal to "area".
    Arguments:
        distance (nd.array): matrix with distances of interest corresponding to an array of points 
        area (float): area covered by the kernel (area = pi*r^2)
    Returns:
        weights (nd.array): matrix with the same size as the distance matrix with corresponding weights for each underlying point (1 or 0).
    '''
    radius=np.sqrt(area/(np.pi))
    return distance < radius