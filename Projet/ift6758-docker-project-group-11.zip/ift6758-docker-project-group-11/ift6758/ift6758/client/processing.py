import numpy as np
import requests
from features import *
import pandas as pd


def download_game(gameID: str):
    '''
    Function to download a single game information from API.

    Args:
        gameID: str - string of gameID
        path: str = '../data' - path to data folder that contains all LNH seasons data files

    '''

    r = requests.get(f"https://statsapi.web.nhl.com/api/v1/game/{gameID}/feed/live/")
    df = pd.DataFrame.from_records(r.json())
    return df

def get_game_info(game_id:str)-> pd.DataFrame:
    '''

    Args:
        game_id:

    Returns:

    '''
    df = download_game(game_id)
    df_game = clean_game_data(df,game_id)
    return df_game[['Arena','team_home','team_away']]

def get_gamelist():
    '''
    get_gamelist returns the gameID of the 10 last game since the current
    date
    '''
    import datetime
    # Get current month and year
    current_month = datetime.date.today().month
    current_year = datetime.date.today().year
    today = datetime.date.today()
    # deduct season_id
    season_id = str(current_year) + str(current_year + 1) if current_month > 7 else str(current_year - 1) + str(
        current_year)

    # get the schedule for the season and create a json file
    url = f"https://statsapi.web.nhl.com/api/v1/schedule?season={season_id}&gameType=R&gameType=P"
    r_seasons = requests.get(url) # download data
    seasons = r_seasons.json()

    # get all the game ids from the schedule
    ids = []

    # for each date
    for date in seasons['dates']:
        # add game id
        current =  datetime.datetime.date(datetime.datetime.strptime(date['date'], '%Y-%m-%d'))
        if today<current:
            break
        #ids += [game['gamePk'] for game in date['games']]
        ids += [game['gamePk'] for game in date['games']]

        # until at least 10 are added


    # return game_id list
    return ids[-10:]

def update_events(game_id:str,tracker_idx: int) -> pd.DataFrame:
    '''
    Function that cleans the event data from the API.
    It removes the columns that are not useful for the analysis and add columns of interest.
    Arguments:
        gameID (str): string of the game ID

    Returns:
        df (pd.DataFrame): DataFrame containing the cleaned data.
    '''
    pd.options.mode.chained_assignment = None


    df = download_game(game_id)
    df_game = clean_game_data(df,game_id)
    df_penalty = clean_pena_data(df, df_game,game_id)
    df = pd.DataFrame(df["liveData"]["plays"]["allPlays"])

    if df.shape[0] == 0:
        columns = ["eventIdx", 'event', 'Shot Type', 'x', 'y', 'isGoal', 'description',
                   'period', 'teamName', 'gameSeconds', 'netEmpty',
                   'gameID', 'distance', 'angle', 'lastEvent', 'last_x',
                   'last_y', 'last_eventDist', 'timeSinceLastEvent',
                   'isRebound', 'speed', 'angle_change',
                   'powerplay_timer', 'sameteam_players', 'opposingteam_players']
        return pd.DataFrame(columns=columns) , [0,'20:00']

    # is game in regular saison or playoff

    isReg = True if game_id[4:6] == '02' else False

    df["eventIdx"] = df["about"].apply(lambda x: x["eventIdx"])

    # Get only event after tracker
    df = df[df.eventIdx >= tracker_idx]

    df["event"] = df["result"].apply(lambda x: x["event"])

    df["Shot Type"] = df["result"].apply(lambda x: x["secondaryType"] if "secondaryType" in x else None)
    if 'coordinates' in df:
        df["eventCoordinates"] = df["coordinates"].apply(
            lambda e: (e["x"], e["y"]) if "x" in e.keys() and "y" in e.keys() else None)
        df['x'] = df["eventCoordinates"].apply(lambda x: (x[0] if x != None else None))
        df['y'] = df["eventCoordinates"].apply(lambda y: (y[1] if y != None else None))
    else:
        df['eventCoordinates'] = None
        df['x'] = None
        df['y'] = None

    df["isGoal"] = df["event"] == "Goal"
    df["description"] = df["result"].apply(lambda x: x["description"])
    df["period"] = df["about"].apply(lambda x: x["period"])
    df["periodTime"] = df["about"].apply(lambda x: x["periodTime"])
    timeList = [df.period.iloc[-1],df.periodTime.iloc[-1] ]
    # df["teamId"] = df["team"].apply(lambda x: x["id"] if not isinstance(x, float) else None)
    if 'team' in df:
        df["teamName"] = df["team"].apply(lambda x: x["name"] if not isinstance(x, float) else None)
    else:
        df['team'] = np.nan
        df['teamName'] = np.nan

    df['min2sec'] = df["periodTime"].apply(lambda x: int(x.split(':')[0]) * 60)

    df['secondes'] = df["periodTime"].apply(lambda x: int(x.split(':')[1]))

    if isReg:
        df['prevperiod_sec'] = df['period'].apply(lambda x: (x - 1) * 20 * 60 if x != 5 else 65 * 60)
    else:
        df['prevperiod_sec'] = df['period'].apply(lambda x: (x - 1) * 20 * 60)

    df["gameSeconds"] = df['min2sec'] + df['secondes'] + df['prevperiod_sec']
    df = df.drop(columns=["min2sec", "secondes", "prevperiod_sec", "periodTime"])
    if 'players' in df:
        df["goalieName"] = df["players"].apply(
            lambda x: x[-1]["player"]["fullName"] if not isinstance(x, float) and x[-1][
                "playerType"] == "Goalie" else None)
        event_goalie = ['Goal', 'Shot']
        df["netEmpty"] = df["goalieName"].isnull() & df['event'].apply(lambda x: (x in event_goalie))
    # df["strength"] = df["result"].apply(lambda x: x["strength"]["name"] if "strength" in x else None)
    else:
        df['players'] = np.nan
        df["goalieName"] = None
        df["netEmpty"] = False
    # drop the columns that are not useful for the analysis anymore
    df = df.drop(columns=["result", "about", "team", "players", "coordinates"])
    df['gameID'] = game_id
    df['distance'] = df.apply(lambda event: create_distance_feature(event, df_game), axis=1)
    df['angle'] = df.apply(lambda event: create_angle_feature(event, df_game), axis=1)

    previous_event = df.copy()
    df['lastEvent'] = None
    df['last_x'] = None
    df['last_y'] = None
    df['last_eventTimes'] = None
    df['last_eventCoordinates'] = None
    df['last_eventDist'] = None
    df['last_angle'] = None

    df['lastEvent'].iloc[1:] = previous_event['event'].iloc[:-1]
    df['last_x'].iloc[1:] = previous_event['x'].iloc[:-1]
    df['last_y'].iloc[1:] = previous_event['y'].iloc[:-1]
    df['last_angle'].iloc[1:] = previous_event['angle'].iloc[:-1]
    df['last_eventTimes'].iloc[1:] = previous_event['gameSeconds'].iloc[:-1]
    df['timeSinceLastEvent'] = df['gameSeconds'] - df['last_eventTimes']
    df['last_eventCoordinates'].iloc[1:] = previous_event['eventCoordinates'].iloc[:-1]
    df['last_eventDist'] = df.apply(lambda x: compute_distance(x.last_eventCoordinates, x.eventCoordinates), axis=1)
    df['isRebound'] = df.apply(lambda x: rebound_identification(x['event'], x['lastEvent']), axis=1)
    df['speed'] = df.apply(lambda x: speed_events(x.last_eventDist, x.timeSinceLastEvent), axis=1)
    df['angle_change'] = df.apply(lambda x: angle_change(x.isRebound, x.angle, x.last_angle, x.x, x.last_x), axis=1)

    df = df.drop(
        columns=["eventCoordinates", "last_eventCoordinates", 'last_eventTimes', "goalieName", 'last_angle'])

    home_penalt_schd, away_penalt_schd = get_penalty_schedule(df_penalty, True), get_penalty_schedule(df_penalty,
                                                                                                      False)
    df['homePlayers'] = df.apply(lambda x: num_player(home_penalt_schd, x.gameSeconds), axis=1)
    df['awayPlayers'] = df.apply(lambda x: num_player(away_penalt_schd, x.gameSeconds), axis=1)
    df['isTeamHome'] = df['teamName'] == df_game['team_home'].item()
    df['timerStartAway'] = df[df['isTeamHome'] == False].apply(
        lambda x: timer_powerplay(away_penalt_schd, x.gameSeconds),
        axis=1)
    df['timerStartAway'].fillna(0, inplace=True)
    df['timerStartAway'] = df['timerStartAway'].astype(int)
    df['timerStartHome'] = df[df['isTeamHome'] == True].apply(
        lambda x: timer_powerplay(home_penalt_schd, x.gameSeconds),
        axis=1)
    df['timerStartHome'].fillna(0, inplace=True)
    df['timerStartHome'] = df['timerStartHome'].astype(int)
    df['powerplay_timer'] = df.apply(
        lambda x: consolidation_timer_pp(x.gameSeconds, x.timerStartHome, x.timerStartAway, x.isTeamHome,
                                         x.teamName), axis=1)
    df['sameteam_players'] = df.apply(
        lambda x: numberplayers_dispatch(x.isTeamHome, x.teamName, x.homePlayers, x.awayPlayers, True), axis=1)
    df['opposingteam_players'] = df.apply(
        lambda x: numberplayers_dispatch(x.isTeamHome, x.teamName, x.homePlayers, x.awayPlayers, False), axis=1)
    df = df.drop(columns=['isTeamHome', 'timerStartHome', 'timerStartAway', 'homePlayers', 'awayPlayers'])
    if isReg:  # if we are in regular season
        season = int(game_id[:4])
        # number of player in prolongation
        df[df["period"] == 4].homePlayer = 3 if season >= 2015 else 4
        df[df["period"] == 4].awayPlayer = 3 if season >= 2015 else 4
        # number of players in shootout
        df[df["period"] == 5].homePlayer = 1
        df[df["period"] == 5].awayPlayer = 1

    df = df.loc[(df['event'] == 'Goal') | (df['event'] == 'Shot')
                | (df['event'] == 'Missed Shot') | (df['event'] == 'Blocked Shot')]

    return df.iloc[1:,:] , timeList

def clean_game_data(df:pd.DataFrame,game_id:str) -> pd.DataFrame:
    '''
    Function that cleans the play-by-play data from the API and keep only
    general game informations by removing specific informations.

    Arguments:
        gameID (str): string of the game ID to import data
        df (str): dataframe with raw informations from API

    Returns:
        Dataframe : dataframe contening a single game informations (cleaned)

    '''

    # Get general Game Info
    df = df.copy()
    arena_name = df["gameData"]["venue"]['name']
    last_period = df["liveData"]["linescore"]['currentPeriod']
    hasShootout = df["liveData"]["linescore"]['hasShootout']
    hasOverTime = last_period == 'OT'
    genInfo = pd.DataFrame([{'Arena': arena_name, 'hasShootout': hasShootout, 'hasOverTime': hasOverTime}])

    # Get Home Team info
    df_home = df["liveData"]["linescore"]['teams']['home']
    df_home['team'] = df_home['team']['name']
    new_key = {key: key + '_home' for key in df_home.keys()}
    df_home = pd.DataFrame([df_home])
    df_home.rename(columns=new_key, inplace=True)

    # Get Away Team info
    df_away = df["liveData"]["linescore"]['teams']['away']
    df_away['team'] = df_away['team']['name']
    new_key = {key: key + '_away' for key in df_away.keys()}
    df_away = pd.DataFrame([df_away])
    df_away.rename(columns=new_key, inplace=True)

    # Get Rink Side per Period Info
    period_list = df['liveData']['linescore']['periods']
    # for shootout goalie defend the same goal they finished defending

    if hasShootout:
        period_list.append(period_list[-2].copy())
        period_list[-1]['num'] = 5
    dic_periods = dict()
    for period in period_list:
        period_num = period['num']
        try:
            home_rink_side = period['home']['rinkSide']
        except KeyError:
            # print(f'rink side missing for game {gameID}, period {period_num}')
            home_rink_side = np.nan
        try:
            away_rink_side = period['away']['rinkSide']
        except KeyError:
            # print(f'rink side missing for game {gameID}, period {period_num}')
            away_rink_side = np.nan

        dic_periods[f'home_rink_side_period_{period_num}'] = [home_rink_side]
        dic_periods[f'away_rink_side_period_{period_num}'] = [away_rink_side]
    df_periods = pd.DataFrame.from_dict(dic_periods)

    # Merge DataFrame
    game_Info = pd.concat([genInfo, df_home, df_away, df_periods], axis=1)
    game_Info['gameID'] = game_id
    game_Info.set_index("gameID", inplace=True)

    return game_Info

def clean_pena_data( df: pd.DataFrame, df_game: pd.DataFrame,game_id: str) -> pd.DataFrame:
    '''
    Function that get penalty information from the API.
    It removes the columns that are not useful for the analysis and add columns of interest.
    Arguments:
        df (pd.DataFrame): DataFrame containing play_by_play data
        df_game (pd.DataFrame): DataFrame containing the cleaned game data
        game_id : game_id number
    Returns:
        df (pd.DataFrame): DataFrame containing the cleaned penalty data.
    '''

    # Check if data already generated :
    df = df.copy()
    df = pd.DataFrame(df["liveData"]["plays"]["allPlays"])

    if df.shape[0] == 0:
        columns = ['gameID', "event", "eventType", 'penaltySev', 'penaltySec', "description",
                   'isTeamHome', 'timeStart', 'timeEnd']
        return pd.DataFrame(columns=columns)

    df = df[df["result"].apply(lambda x: "event" in x and x["event"] in ['Penalty'])]
    if df.shape[0] == 0:
        columns = ['gameID', "event", "eventType", 'penaltySev', 'penaltySec', "description",
                   'isTeamHome', 'timeStart', 'timeEnd']
        return pd.DataFrame(columns=columns)
    # is game in regular saison or playoff
    isReg = True if game_id[4:6] == '02' else False

    df['gameID'] = game_id
    df["event"] = df["result"].apply(lambda x: x["event"])
    df["eventType"] = df["result"].apply(lambda x: x["secondaryType"] if "secondaryType" in x else None)

    df['penaltySev'] = df['result'].apply(lambda x: x["penaltySeverity"])
    df['penaltySec'] = df['result'].apply(lambda x: 60 * x["penaltyMinutes"])
    df["description"] = df["result"].apply(lambda x: x["description"])
    df["period"] = df["about"].apply(lambda x: x["period"])
    df["periodTime"] = df["about"].apply(lambda x: x["periodTime"])
    df["teamId"] = df["team"].apply(lambda x: x["id"] if x is not None else None)
    df["teamName"] = df["team"].apply(lambda x: x["name"])

    df['isTeamHome'] = df['teamName'] == df_game['team_home'].item()

    df['min2sec'] = df["periodTime"].apply(lambda x: int(x.split(':')[0]) * 60)
    df['secondes'] = df["periodTime"].apply(lambda x: int(x.split(':')[1]))

    if isReg:
        df['prevperiod_sec'] = df['period'].apply(lambda x: (x - 1) * 20 * 60 if x != 5 else 65 * 60)
    else:
        df['prevperiod_sec'] = df['period'].apply(lambda x: (x - 1) * 20 * 60)

    df['timeStart'] = df['min2sec'] + df['secondes'] + df['prevperiod_sec']
    df['timeEnd'] = df['timeStart'] + df['penaltySec']

    df = df.drop(columns=["result", "about", "team", "players", "coordinates", 'prevperiod_sec',
                          'min2sec', 'secondes', 'periodTime'])

    df = df.drop(columns=["period", "teamId", "teamName"])

    return df

def convert_to_inputs(df: pd.DataFrame)-> pd.DataFrame:
    '''

    Args:
        game_id: str

    Returns:

    '''

    columns = ['distance', 'angle', 'gameSeconds', 'period', 'x', 'y', 'last_x',
       'last_y', 'timeSinceLastEvent', 'last_eventDist', 'isRebound',
       'angle_change', 'speed', 'powerplay_timer', 'sameteam_players',
       'opposingteam_players', 'netEmpty',
       'Shot Type_Backhand', 'Shot Type_Deflected',
       'Shot Type_Slap Shot',  'Shot Type_Snap Shot',
       'Shot Type_Tip-In','Shot Type_Wrap-around',
       'Shot Type_Wrist Shot', 'lastEvent_Blocked Shot', 'lastEvent_Faceoff',
       'lastEvent_Giveaway', 'lastEvent_Goal', 'lastEvent_Hit',
       'lastEvent_Missed Shot', 'lastEvent_Penalty', 'lastEvent_Shot',
       'lastEvent_Takeaway']

    template = pd.DataFrame(columns=columns)

    features = ['distance', 'angle', 'gameSeconds',
               'period', 'x', 'y', 'Shot Type', 'lastEvent',
               'last_x', 'last_y', 'timeSinceLastEvent', 'last_eventDist',
               'isRebound', 'angle_change', 'speed', 'powerplay_timer',
               'sameteam_players', 'opposingteam_players', 'netEmpty']

    features_to_cast_to_int = ["isGoal", "gameSeconds", "period", "isRebound", "x", "y", "last_x", "last_y",
                           "timeSinceLastEvent", "powerplay_timer", "sameteam_players", "opposingteam_players",
                           "netEmpty"]
    df.fillna(0,inplace=True)

    for feature in features_to_cast_to_int:
        if feature in df.columns:
            df[feature] = df[feature].astype(int)

    features_to_ohe = ["Shot Type", "lastEvent"]


    X = df[features]

    for feature in features_to_ohe:

        if feature in X.columns:
            X = pd.get_dummies(X, columns=[feature])
    X = pd.concat([template,X])
    X.fillna(0,inplace=True)
    return X

def totimeremain(timePeriod: str)->str:
    '''

    Args:
        timePeriod:

    Returns:

    '''
    remaining_second = 20*60 - (int(timePeriod.split(':')[0]) * 60 + int(timePeriod.split(':')[1]))
    minute_rem =  int(remaining_second/60)
    sec_rem = int(remaining_second-minute_rem*60)
    return str(minute_rem)+':'+str(sec_rem)
