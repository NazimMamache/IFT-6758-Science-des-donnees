import os
import re
import streamlit as st
import pandas as pd
import numpy as np
import requests
import json
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.graph_objects as go

from data_controller import DataController
from comet_ml import API

"""
General template for your streamlit app.
Feel free to experiment with layout and adding functionality!
Just make sure that the required functionality is included as well
"""

dc = DataController()
api = API(api_key=os.environ.get("COMET_API_KEY"))
saved_game_id = dc.game_id

def on_selection_change(selection):
    pattern = r"\d{4}(02|03)\d{4}"
    if not re.match(pattern, selection):
        st.warning(f"Game id {selection} does not match pattern {pattern}")
    else:
        dc.switch_game(selection)

def second_to_period_time(second):
    time = f"{second // 3600:02d}:{second % 3600 // 60:02d}:{second % 60:02d}"
    time = pd.to_datetime(time, format="%H:%M:%S").time()
    return time


st.title("NHL Visualization App")

with st.sidebar:
    st.subheader("Download model from Comet ML")

    workspace = st.selectbox("Workspace", ["clemdetry"], index=0)

    model_options = ["XGBoost", "Random Forest", "Logistic Regression"]
    model = st.selectbox("Model", model_options, index=0)
    model_dic = {
        "XGBoost": "xgboostclassifier1",
        "Random Forest": "randomforest",
        "Logistic Regression": "logisticregression"
    }
    model_name = model_dic[model]

    version_options = []
    if model_name == "xgboostclassifier1":
        version_options = ["1.0.0"]
    elif model_name == "randomforest":
        version_options = ["1.0.0", "1.0.1", "1.0.2"]
    elif model_name == "logisticregression":
        version_options = ["1.0.0", "1.0.1", "1.0.2"]
    version = st.selectbox("Version", version_options, index=0)

    if st.button("Download"):
        api.download_registry_model(workspace, model_name, version, output_path=f"models/{model_name}/{version}", expand=True)


with st.container():

    game_id = st.text_input("Choose a game id", dc.game_id)

    if st.button("Ping"):

        if game_id != saved_game_id:
            on_selection_change(game_id)
            saved_game_id == game_id
        else:
            dc.ping()

        st.subheader(f"Game {dc.game_id} - {dc.team_home} vs {dc.team_away}")

        st.text(f"Period {dc.period}: {dc.periodTime}")

        col1, col2 = st.columns(2)

        with col1:
            st.text(f"{dc.team_home} xG (actual)")
            st.subheader(f"{dc.pred_home} ({dc.goal_home})")
            st.text(f"{round(dc.pred_home-dc.goal_home, 3)}")

        with col2:
            st.text(f"{dc.team_away} xG (actual)")
            st.subheader(f"{dc.pred_away} ({dc.goal_away})")
            st.text(f"{round(dc.pred_away-dc.goal_away, 3)}")

        st.subheader("Data used for prediction and model output")
        st.write(dc.current_data)

        st.subheader("xG prediction edge on the game")
        l = [0]
        period_time = []
        for index, row in dc.current_data.iterrows():
            if row["Prediction"] > 0.2:
                if row["teamName"] == dc.team_home:
                    l.append(l[-1] + row["Prediction"])
                if row["teamName"] == dc.team_away:
                    l.append(l[-1] - row["Prediction"])
                period_time.append(second_to_period_time(row["gameSeconds"]))

        st.write(f"Voici une fonctionnalité BONUS permettant de comparer les xG en fonction du temps.")
        st.write(f"Lorsque la courbe est au-dessus de l'axe x = 0, c'est l'équipe {dc.team_home} qui a l'avantage. Lorsque la courbe est en dessous de l'axe x = 0, c'est l'équipe {dc.team_away} qui a l'avantage.")
        st.write("Le graphe est divisé en quarts-temps")

        y_positive = [value if value >= 0 else 0 for value in l]
        y_negative = [value if value < 0 else 0 for value in l]

        fig = go.Figure()
        fig.add_trace(go.Scatter(x=period_time, y=y_positive, name=f"xG value edge\n ({dc.team_home} advantage)", fill='tozeroy', mode= 'none'))
        fig.add_trace(go.Scatter(x=period_time, y=y_negative, name=f"xG value edge\n ({dc.team_away} advantage)", fill='tozeroy', mode= 'none'))
        fig.update_layout(
            xaxis_title="Time",
            yaxis_title=f"{dc.team_away} advantage                   {dc.team_home} advantage",
            showlegend=True,
            height=500,
        )
        fig.add_vline(x=0, line_width=0, line_dash="dash", line_color="green", annotation_text="  Period 1", annotation_position="bottom right")
        fig.add_vline(x=15, line_width=3, line_dash="dash", line_color="green", annotation_text="  Period 2", annotation_position="bottom right")
        fig.add_vline(x = 30, line_width=3, line_dash="dash", line_color="green", annotation_text="  Period 3", annotation_position="bottom right")
        fig.add_vline(x = 45, line_width=3, line_dash="dash", line_color="green", annotation_text="  Period 4", annotation_position="bottom right")
        fig.add_hline(y=0, line_dash="dot", 
              line_color="white",
              annotation_text="advantage",
              annotation_position="bottom right",
              annotation_font_size=10,
              annotation_font_color="white"
             )
        fig.update_layout(
        autosize=False,
        width=1000,
        height=500)
        fig.update_xaxes(tickangle=45)
        y0 = min(l)
        y1 = max(l)
        y_max = max(abs(y0), abs(y1))
        fig.update_yaxes(range=[-y_max, y_max])
        st.plotly_chart(fig)

st.markdown("")
