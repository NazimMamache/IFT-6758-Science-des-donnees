#!/bin/bash

docker run -p 8080:8080 -t -i app
