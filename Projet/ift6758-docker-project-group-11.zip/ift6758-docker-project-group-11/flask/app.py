"""
If you are in the same directory as this file (app.py), you can run run the app using gunicorn:
    
    # unix:
    $ gunicorn --bind 0.0.0.0:8080 app:app
    # windows:
    $ waitress-serve --listen=0.0.0.0:8080 app:app

gunicorn and waitress can be installed via:

    $ pip install gunicorn
    $ pip install waitress

"""
import os
import logging
from flask import Flask, jsonify, request, abort
import pandas as pd
import joblib

from comet_ml import API

experiment = [0]

def comet_model_loader(json):
    """
    Loads a model from the Comet ML registry. The model is downloaded and loaded into memory
    using joblib. The model is then stored in the global variable `model`.

    Args:
        json (dict): A dictionary with the following schema:

            {
                workspace: (required),
                model: (required),
                version: (required),
                ... (other fields if needed) ...
            }
    """
    global model
    api = API(api_key=os.environ.get("COMET_API_KEY"))
    try:
        # first, try to download the model locally
        model = joblib.load(f"models/{json['model']}/weights.pkl")
        succes = True
        code = 200
        error = "model correctly loaded locally"
    except Exception as e:
        # if the model is not found locally, try to download it from the registry comet
        try:
            api.download_registry_model(json["workspace"], json["model"], json["version"], output_path=f"models/{json['model']}", expand=True)
            model = joblib.load(f"models/{json['model']}/weights.pkl")
            succes = True
            code = 201
            error = f"model correctly loaded from comet with the following error: {e}"
        except Exception as e:
            succes = False
            code = 400
            error = f"model could not be found by comet with the following error: {e}"
    response = {
        "succes": succes,
        "code": code,
        "error": error,
    }
    return response


LOG_FILE = os.environ.get("FLASK_LOG", "flask.log")


app = Flask(__name__)


@app.before_first_request
def before_first_request():
    """
    Hook to handle any initialization before the first request (e.g. load model,
    setup logging handler, etc.)
    """
    logging.basicConfig(filename=LOG_FILE, level=logging.INFO)

    default = {
        "workspace": "clemdetry",
        "model": "xgboostclassifier1",
        # "model": "randomforest",
        "version": "1.0.0",
    }
    comet_model_loader(default)


@app.route("/logs", methods=["GET"])
def logs():
    """Reads data from the log file and returns them as the response"""
    with open("flask.log", "r") as f:
        response = f.read().splitlines()
    
    resp_dic = {}
    for (i, line) in enumerate(response):
        index = str(i)
        resp_dic[index] = line
    
    return jsonify(resp_dic)  # response must be json serializable!


@app.route("/download_registry_model", methods=["POST"])
def download_registry_model():
    """
    Handles POST requests made to http://IP_ADDRESS:PORT/download_registry_model

    The comet API key should be retrieved from the ${COMET_API_KEY} environment variable.

    Recommend (but not required) json with the schema:

        {
            workspace: (required),
            model: (required),
            version: (required),
            ... (other fields if needed) ...
        }
    
    """
    # Get POST json data
    json = request.get_json()
    app.logger.info(json)

    app.logger.info(f"JSON: {json}")

    response = comet_model_loader(json)
    app.logger.info(response)
    return jsonify(response)  # response must be json serializable!


@app.route("/predict", methods=["POST"])
def predict():
    """
    Handles POST requests made to http://IP_ADDRESS:PORT/predict

    Returns predictions
    """
    # Get POST json data
    json = request.get_json()
    app.logger.info(json)

    data = pd.DataFrame.from_dict(json)

    app.logger.info(data.head(3))
    response = None
    try:
        response = model.predict_proba(data)[:,-1]
        app.logger.info("prediction correctly made")
    except Exception as e:
        app.logger.info(f"prediction failed with the following error: {e}")
    
    return pd.Series(response.flatten()).to_json(orient="values")
